enum LikeType{
   like,
   love,
   haha,
   wow,
   angry,
   sad
}