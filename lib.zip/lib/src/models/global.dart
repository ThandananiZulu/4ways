import 'package:flutter/material.dart';
import 'user.dart';
import 'like.dart';
import 'comment.dart';
import 'post.dart';


String userProfileImage = 'https://images.unsplash.com/photo-1499363536502-87642509e31b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80';
String userStoryCoverImage = 'https://picsum.photos/200/300';

String myStoryImage = 'https://images.unsplash.com/photo-1578133671540-edad0b3d689e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1351&q=80';

String firstName = 'Wiseman';
String lastName = 'Dlungwana';
