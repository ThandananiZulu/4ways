import 'likeType.dart';
import 'User.dart';

class Like{

  late User user;
  late LikeType likeType;

}